local controller = {}

controller.name = "LeniencyHelper/Controllers/RemoveDBlockCCorection"
controller.depth = -1000000
controller.texture = "objects/LeniencyHelper/Controllers/genericController"
controller.placements = {
    {
        name = "Remove dreamblock corner-corection Controller",
        data = {
            StopFlag = "",
            Persistent = true
        }
    }
}

return controller