local ClearBlockBoostTrigger = {}

ClearBlockBoostTrigger.name = "LeniencyHelper/ClearBlockBoostTrigger"
ClearBlockBoostTrigger.triggerText = "Clear Blockboost Trigger"
ClearBlockBoostTrigger.depth = -1000000
ClearBlockBoostTrigger.placements = {
    {
        name = "Clear Blockboost Trigger",
        data = {
            Flag = "",
            OneUse = false
         }
    }
}

return ClearBlockBoostTrigger